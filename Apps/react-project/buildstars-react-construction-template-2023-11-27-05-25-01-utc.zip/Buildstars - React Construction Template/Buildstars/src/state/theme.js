export default {
  color: "#ffc526"
};
